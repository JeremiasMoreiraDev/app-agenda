package com.example.catalogoservicosmanutencao;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout servicoInstalacao =
                findViewById(R.id.servicoInstalacao);

        LinearLayout servicoManutencao =
                findViewById(R.id.servicoManutencao);

        LinearLayout servicoMonitoramento =
                findViewById(R.id.servicoMonitoramento);

        Button btnContato =
                findViewById(R.id.btnContato);

        // SERVIÇO 1: INSTALAÇÃO
        servicoInstalacao.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    InstalacaoActivity.class
            );
            startActivity(intent);
        });

        // SERVIÇO 2: MANUTENÇÃO
        servicoManutencao.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    ManutencaoActivity.class
            );
            startActivity(intent);
        });

        // SERVIÇO 3: MONITORAMENTO
        servicoMonitoramento.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    MonitoramentoActivity.class
            );
            startActivity(intent);
        });

        // BOTÃO: SOLICITAR ORÇAMENTO
        btnContato.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    OrcamentoActivity.class
            );
            startActivity(intent);
        });
    }
}

